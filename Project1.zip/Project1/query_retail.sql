SELECT * FROM retail_price_project1
WHERE product_id IS NULL OR product_weight_g IS NULL;
SELECT product_id, month_year, COUNT(*) FROM retail_price_project1
GROUP BY product_id, month_year HAVING COUNT(*) > 1;
ALTER TABLE retail_price_project1
MODIFY COLUMN unit_price DECIMAL(10,2),
MODIFY COLUMN total_price DECIMAL(10,2),
MODIFY COLUMN qty INT,
MODIFY COLUMN product_weight_g DECIMAL(10,2),
MODIFY COLUMN product_score DECIMAL(3,2);
--  Assume cost is 70% of unit_price and creating cost price column
ALTER TABLE retail_price_project1 ADD COLUMN cost_price DECIMAL(10,2);
SET SQL_SAFE_UPDATES = 0;
UPDATE retail_price_project1
SET cost_price = unit_price * 0.7; 
SET SQL_SAFE_UPDATES = 1;
 --  Add Computed Fields Profit & Margin
SET SQL_SAFE_UPDATES = 0;
ALTER TABLE retail_price_project1
ADD COLUMN profit DECIMAL(10,2),
ADD COLUMN profit_margin DECIMAL(5,2);
UPDATE retail_price_project1
SET profit = (unit_price - cost_price) * qty,
    profit_margin = ROUND(((unit_price - cost_price) / unit_price) * 100, 2);
SET SQL_SAFE_UPDATES = 1;
-- profit based product catergory and sub category wise
SELECT
  product_category_name, product_id,
  SUM(qty) AS total_units_sold,
  SUM(total_price) AS total_sales,
  SUM(cost_price * qty) AS total_cost,
  SUM(profit) AS total_profit,
  ROUND((SUM(profit) / SUM(total_price)) * 100, 2) AS profit_margin_percent
FROM retail_price_project1
GROUP BY product_category_name, product_id
ORDER BY total_profit DESC;

-- top 5 profitable products
SELECT product_id, product_category_name, SUM(profit) AS total_profit
FROM retail_price_project1
GROUP BY product_id, product_category_name
ORDER BY total_profit DESC
LIMIT 5;

-- bottom 5 profitable products
SELECT product_id, product_category_name, SUM(profit) AS total_profit
FROM retail_data
GROUP BY product_id, product_category_name
ORDER BY total_profit ASC
LIMIT 5;
select * from retail_price_project1;